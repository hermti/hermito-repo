![xStream logo](https://github.com/xStream-Kodi/plugin.video.xstream/blob/wiki/graphics/web/logo-dark.png?raw=true)


## Willkommen bei xStream für Kodi!

Bei xStream handelt es sich um ein Video-Addon für Kodi, welches das streamen von Filmen und Serien über eine intuitive und optisch ansprechende Benutzeroberfläche ermöglicht. Sowohl der Funktionsumfang von xStream als auch das Angebot an Streaming-Inhalten wird von den beteiligten Entwicklern stetig weiterentwickelt bzw. um neue Webseiten erweitert. Diese werden auch als Site-Plugins bezeichnet, welche auf die eigentlichen Quellen verweisen die für das bereitgestellte Angebot verantworlich sind! 
***

[![Join the chat at https://gitter.im/Lastship_Chat/xStream](https://badges.gitter.im/Lastship_Chat/xStream.svg)](https://gitter.im/Lastship_Chat/xStream?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)

### | [Forum](http://lastship.square7.ch/forum/forumdisplay.php?fid=15) | [Site-Plugin Wunschliste](https://docs.google.com/spreadsheets/d/1b_9C6BONlpWcugMgocFbKxe7nFp99HfvVUJznxTzT4I/edit?usp=sharing) | [GitHub](https://github.com/lastship/plugin.video.xstream/tree/nightly) | [FAQ](https://github.com/lastship/xStream-FAQ/blob/master/xStream_Anleitung_FAQ.md)

