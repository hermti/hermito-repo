import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmdob3N0LmlwdHY=')

name = b.b64decode('W0JdW0NPTE9SIGxpZ2h0eWVsbG93XUdob3N0IElQVFZbL0NPTE9SXVsvQl0=')

#host = b.b64decode('aHR0cDovLzE0NC4yMTcuNzguNzg=')
host = b.b64decode('aHR0cDovL3R2LmlwdHZwYW5lbC50dg==')
port = b.b64decode('ODA4MA==')
